package com.jsw.mes.mdm.service.impl;

import com.jsw.mes.mdm.entity.ProcessMaster;
import com.jsw.mes.mdm.entity.UnitMaster;
import com.jsw.mes.mdm.entity.WorkCenterMaster;
import com.jsw.mes.mdm.exception.BadRequestException;
import com.jsw.mes.mdm.exception.WorkCenterException;
import com.jsw.mes.mdm.mapper.WorkCenterMapper;
import com.jsw.mes.mdm.model.request.WorkCenterRequest;
import com.jsw.mes.mdm.model.response.WorkCenterResponse;
import com.jsw.mes.mdm.repository.PlantMasterRepository;
import com.jsw.mes.mdm.repository.ProcessMasterRepository;
import com.jsw.mes.mdm.repository.UnitMasterRepository;
import com.jsw.mes.mdm.repository.WorkCenterMasterRepository;
import com.jsw.mes.mdm.service.WorkCenterMasterService;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Log4j2
public class WorkCenterMasterServiceImpl implements WorkCenterMasterService {

    private final UnitMasterRepository unitMasterRepository;

    private final ProcessMasterRepository processMasterRepository;

    private final WorkCenterMasterRepository workCenterMasterRepository;

    private final WorkCenterMapper workCenterMapper;

    public WorkCenterMasterServiceImpl(WorkCenterMasterRepository workCenterMasterRepository, WorkCenterMapper workCenterMapper,
                                       PlantMasterRepository plantMasterRepository,
                                       UnitMasterRepository unitMasterRepository, ProcessMasterRepository processMasterRepository) {
        this.workCenterMasterRepository = workCenterMasterRepository;
        this.workCenterMapper = workCenterMapper;
        this.unitMasterRepository = unitMasterRepository;
        this.processMasterRepository = processMasterRepository;
    }






    @Override
    public WorkCenterResponse addWorkCenter(WorkCenterRequest workCenterRequest) throws WorkCenterException {
        workCenterRequest.setIsActive("Y");

        Optional<WorkCenterMaster> workCenterMasterOptional=workCenterMasterRepository.findByWorkCenterNameAndIsActive(workCenterRequest.getWorkCenterName(), "Y");
        log.info("Query to fetch the list if any existing ProcessName is matching with given processName ");
       if(!workCenterMasterOptional.isEmpty()){
           log.error("Work-Center Already exists with the given workCenterName");
           throw  new WorkCenterException("Work-Center Already exists with the given workCenterName", HttpStatus.NOT_FOUND);
       }

       WorkCenterMaster workCenterMaster=workCenterMapper.toEntity(workCenterRequest);
       log.info("WorkCenterRequest is mapped to WorkCenterMaster");

       UnitMaster unitMaster=getUnitMaster(workCenterRequest.getUnitId());
        log.info("UnitMaster was found with the help of unitId");

        ProcessMaster processMaster=getProcessMaster(workCenterRequest.getProcessId());
        log.info("ProcessMaster was found with the help of processId");

        workCenterMasterRepository.save(workCenterMaster);
        log.info("WorkCenter record is saved");

        unitMaster.getWorkCenterMstList().add(workCenterMaster);
        unitMasterRepository.save(unitMaster);
        log.info("WorkCenterMaster is mapped to UnitMaster");

        processMaster.getWorkCenterMstList().add(workCenterMaster);
        processMasterRepository.save(processMaster);
        log.info("WorkCenterMaster is mapped to ProcessMaster");

        return workCenterMapper.toResponse(workCenterMaster,unitMaster.getUnitId(),processMaster.getProcessId());

    }

    private ProcessMaster getProcessMaster(int processId) throws WorkCenterException {
        return processMasterRepository.findByProcessNameAndIsActive(String.valueOf(processId),"Y")
                .orElseThrow(()-> new WorkCenterException("ProcessId Not Found",HttpStatus.NOT_FOUND));
    }

    private UnitMaster getUnitMaster(int unitId) throws WorkCenterException {
        return unitMasterRepository.findByUnitIdAndIsActive(unitId,"Y")
                .orElseThrow(()  ->new WorkCenterException("UnitIdFound",HttpStatus.NOT_FOUND));
    }


    @Override
    public WorkCenterResponse updateWorkCenter(WorkCenterRequest workCenterRequest) throws WorkCenterException {
        Optional<WorkCenterMaster> workCenterMasterOptional = workCenterMasterRepository.findByWorkCenterNameAndIsActive(workCenterRequest.getWorkCenterName(),"Y");
        log.info("Query to fetch the list if any existing workCenterName is matching with given workCenterName ");


        UnitMaster unitMaster=getUnitMaster(workCenterMasterOptional.get().getWorkCenterId());
        log.info("UnitMaster was found with the help of unitId");

        ProcessMaster processMaster=getProcessMaster(workCenterMasterOptional.get().getWorkCenterId());
        log.info("ProcessMaster was found with the help of processId");

        WorkCenterMaster mapperWorkCenterMaster= workCenterMapper.toEntity(workCenterRequest);
        log.info("WorkCenterRequest is mapped To WorkCenterMAster");

        mapperWorkCenterMaster.setWorkCenterId(workCenterMasterOptional.get().getWorkCenterId());
        workCenterMasterRepository.save(mapperWorkCenterMaster);

        if(!unitMaster.getWorkCenterMstList().stream().anyMatch(workCenter ->workCenter.getWorkCenterId()== workCenterMasterOptional.get().getWorkCenterId())){
            unitMaster.getWorkCenterMstList().add(mapperWorkCenterMaster);
            unitMasterRepository.save(unitMaster);
            log.info("WorkCenterMaster is mapped to UnitMaster if it is not mapped already");
        }

        if(!processMaster.getWorkCenterMstList().stream().anyMatch(workCenter ->workCenter.getWorkCenterId()== workCenterMasterOptional.get().getWorkCenterId())) {
            processMaster.getWorkCenterMstList().add(mapperWorkCenterMaster);
            processMasterRepository.save(processMaster);
            log.info("WorkCenterMaster is mapped to ProcessMaster if it is not mapped already");
        }

        return workCenterMapper.toResponse(mapperWorkCenterMaster, unitMaster.getUnitId(), processMaster.getProcessId());

    }

    @Override
    public WorkCenterResponse getWorkCenter(int workCenterId) throws WorkCenterException {
        WorkCenterMaster workCenterMaster = workCenterMasterRepository.findById(workCenterId)
                .orElseThrow(() -> new WorkCenterException("WorkCenter does not exists with th given workCenterName", HttpStatus.NOT_FOUND));


        List<UnitMaster> unitMasterList = unitMasterRepository.findAll()
                .stream()
                .filter(unitMaster -> unitMaster.getWorkCenterMstList().stream().anyMatch(workCenter -> workCenter.getWorkCenterId() == workCenterId))
                .collect(Collectors.toList());

        List<ProcessMaster> processMasterList = processMasterRepository.findAll()
                .stream()
                .filter(processMaster -> processMaster.getWorkCenterMstList().stream().anyMatch(workCenter -> workCenter.getWorkCenterId() == workCenterId))
                .collect(Collectors.toList());

        return workCenterMapper.toResponse(workCenterMaster,unitMasterList.get(0).getUnitId(),processMasterList.get(0).getProcessId());

    }
    @Override
    public WorkCenterResponse deleteWorkCenter(int workCenterId) throws WorkCenterException {
        WorkCenterMaster workCenterMaster = workCenterMasterRepository.findById(workCenterId)
                .orElseThrow(() ->new WorkCenterException("WorkCenter does not exists with th given workCenterName",HttpStatus.NOT_FOUND));

        workCenterMaster.setIsActive("N");

        return workCenterMapper.toResponse(workCenterMasterRepository.save(workCenterMaster));
    }

    @Override
    public List<WorkCenterResponse> getAllWorkCenters() throws WorkCenterException {
        List<WorkCenterMaster> workCenterMasters = workCenterMasterRepository.findAll();

        if(workCenterMasters.isEmpty()){
            throw  new WorkCenterException("No records Found ",HttpStatus.NOT_FOUND);
        }
        return workCenterMasters.stream().map(workCenterMaster -> {
            try {
                return getWorkCenter(workCenterMaster.getWorkCenterId());
            } catch (WorkCenterException e) {
                throw new RuntimeException(e);
            }
        }).collect(Collectors.toList());

    }
}
