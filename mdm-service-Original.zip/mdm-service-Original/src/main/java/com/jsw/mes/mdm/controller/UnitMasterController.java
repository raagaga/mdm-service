package com.jsw.mes.mdm.controller;

import lombok.extern.log4j.Log4j2;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/unit-master")
@Log4j2
public class UnitMasterController {
}
