package com.jsw.mes.mdm.controller;

import com.jsw.mes.mdm.entity.PlantMaster;
import com.jsw.mes.mdm.entity.WorkCenterMaster;
import com.jsw.mes.mdm.exception.WorkCenterException;
import com.jsw.mes.mdm.mapper.WorkCenterMapper;
import com.jsw.mes.mdm.model.request.PlantRequest;
import com.jsw.mes.mdm.model.request.WorkCenterRequest;
import com.jsw.mes.mdm.model.response.PlantResponse;
import com.jsw.mes.mdm.model.response.Response;
import com.jsw.mes.mdm.model.response.WorkCenterResponse;
import com.jsw.mes.mdm.service.WorkCenterMasterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/work-center-master")
@Log4j2
public class WorkCenterMasterController {

    private final WorkCenterMasterService workCenterMasterService;
    private final WorkCenterMapper workCenterMapper;

    public WorkCenterMasterController(WorkCenterMasterService workCenterMasterService, WorkCenterMapper workCenterMapper) {
        this.workCenterMasterService = workCenterMasterService;
        this.workCenterMapper = workCenterMapper;
    }

    @PostMapping
    @Operation(summary = "Adding Work-Center")
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "201", description = "Work-center created successfully"),
                    @ApiResponse(responseCode = "404", description = "InvalidUnitId",content  = @Content),
                    @ApiResponse(responseCode = "404", description = "InvalidProcessId", content = @Content),
            })
    public ResponseEntity<Response<WorkCenterResponse>> addWorkCenter(@RequestBody WorkCenterRequest workCenterRequest) throws WorkCenterException {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Response.of(workCenterMasterService.addWorkCenter(workCenterRequest)));
    }

    @GetMapping
    @Operation(summary = "Get All Work-Center")
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "Work-center retrieved successfully"),
                    @ApiResponse(responseCode = "404", description = "No records found", content = @Content),
                    @ApiResponse(responseCode = "400", description = "InvalidFilterValue ", content = @Content),
            })
    public ResponseEntity<Response<List<WorkCenterResponse>>> getAllWorkCenters() throws WorkCenterException {
        return ResponseEntity.status(HttpStatus.OK)
                .body(Response.of(workCenterMasterService.getAllWorkCenters()));
    }
    @GetMapping("/{workCenterId}")
    @Operation(summary = "Get Work-Center")
    @ApiResponses(
            value = {
                    @ApiResponse(responseCode = "200", description = "Work-center retrieved successfully"),
                    @ApiResponse(responseCode = "404", description = "InvalidWorkCenterId ",content = @Content),
            })
    public ResponseEntity<Response<WorkCenterResponse>> getWorkCenter(@RequestParam("workCenterId") int workCenterId) throws WorkCenterException {
        return ResponseEntity.ok(
                Response.of(workCenterMasterService.getWorkCenter(workCenterId)));
    }

    @PutMapping
    @Operation(summary ="Update Work-Center")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Work-center updated successfully"),
            @ApiResponse(responseCode = "404", description = "InvalidWorkCenterId ",content = @Content),
            @ApiResponse(responseCode = "404", description = "InvalidUnitId",content = @Content),
            @ApiResponse(responseCode = "404", description = "InvalidProcessId", content = @Content),
            })
    public ResponseEntity<Response<WorkCenterResponse>> updateWorkCenter(@RequestBody WorkCenterRequest workCenterRequest) throws WorkCenterException {
        return ResponseEntity.status(HttpStatus.OK)
                .body(Response.of(workCenterMasterService.updateWorkCenter(workCenterRequest)));
    }

    @DeleteMapping("/{workCenterId}")
    @Operation(summary = "Delete Work-Center")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Work-center deleted successfully"),
            @ApiResponse(responseCode = "404", description = "InvalidWorkCenterId ", content = @Content),
            })
    public ResponseEntity<Response<WorkCenterResponse>> deleteWorkCenter(@RequestParam("workCenterId") int workCenterId) throws WorkCenterException {

        return ResponseEntity.ok(
                Response.of(workCenterMasterService.deleteWorkCenter(workCenterId)));
    }
}

