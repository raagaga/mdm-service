package com.jsw.mes.mdm.mapper;


import com.jsw.mes.mdm.entity.ProcessMaster;
import com.jsw.mes.mdm.entity.UnitMaster;
import com.jsw.mes.mdm.entity.WorkCenterMaster;
import com.jsw.mes.mdm.model.request.ProcessMasterRequest;
import com.jsw.mes.mdm.model.request.WorkCenterRequest;
import com.jsw.mes.mdm.model.response.ProcessMasterResponse;
import com.jsw.mes.mdm.model.response.WorkCenterResponse;
import org.springframework.stereotype.Component;

@Component
public class WorkCenterMapper
        implements EntityMapper<WorkCenterRequest, WorkCenterMaster>,ResponseMapper<WorkCenterMaster, WorkCenterResponse> {
    @Override
    public WorkCenterMaster toEntity(WorkCenterRequest workCenterRequest) {

        return WorkCenterMaster.builder()
                .workCenterName(workCenterRequest.getWorkCenterName())
                .workCenterDescription(workCenterRequest.getWorkCenterDescription())
                .isActive(workCenterRequest.getIsActive())
                .build();

    }

    @Override
    public WorkCenterResponse toResponse(WorkCenterMaster workCenterMaster) {

        return WorkCenterResponse.builder()
                .workCenterId(workCenterMaster.getWorkCenterId())
                .workCenterName(workCenterMaster.getWorkCenterName())
                .workCenterDescription(workCenterMaster.getWorkCenterDescription())
                .isActive(workCenterMaster.getIsActive())
                .build();
    }


    public WorkCenterResponse toResponse(WorkCenterMaster workCenterMaster, long primaryId, long secondaryId) {
        return WorkCenterResponse.builder()
                .workCenterId(workCenterMaster.getWorkCenterId())
                .unitId((int) primaryId)
                .processId((int) secondaryId)
                .workCenterName(workCenterMaster.getWorkCenterName())
                .workCenterDescription(workCenterMaster.getWorkCenterDescription())
                .isActive(workCenterMaster.getIsActive())
//               .createdBy(workCenterMaster.getCreatedBy())
//                .createdDt(workCenterMaster.getCreatedDt())
//                .modifiedBy(workCenterMaster.getModifiedBy())
//                .modifiedDt(workCenterMaster.getModifiedDt())
                .build();

    }
    public WorkCenterMaster toEntity(WorkCenterRequest workCenterRequest, int id) {

        return WorkCenterMaster.builder()
                .workCenterId(id)
                .workCenterName(workCenterRequest.getWorkCenterName())
                .workCenterDescription(workCenterRequest.getWorkCenterDescription())
                .isActive(workCenterRequest.getIsActive())
                .build();


    }
}
