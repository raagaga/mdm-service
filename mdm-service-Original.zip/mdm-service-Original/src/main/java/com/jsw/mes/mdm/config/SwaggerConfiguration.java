package com.jsw.mes.mdm.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

/**
 * This class is written for configuring the swagger V3
 */
@Configuration
@Slf4j
public class SwaggerConfiguration {

}
