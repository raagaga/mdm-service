package com.jsw.mes.mdm.repository;

import com.jsw.mes.mdm.entity.WorkCenterMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WorkCenterMasterRepository extends JpaRepository<WorkCenterMaster,Integer> {

    Optional<WorkCenterMaster> findByWorkCenterNameAndIsActive(String workCenterName,String y);
}
//    public WorkCenterMaster findByWorkCenterNameAndIsActive(String workCenterName, String y);
//
//    public List<WorkCenterMaster> findAllByIsActive(String isActive);
//
//    public WorkCenterMaster findByWorkCenterIdAndIsActive(int workCenterId, String isActive);
//
//
//    @Query(value= "update mes_work_center_mst set isActive='Y' where workCenterId=:workCenterId",nativeQuery = true)
//    public WorkCenterMaster updateWorkCenter(int workCenterId);
//}
