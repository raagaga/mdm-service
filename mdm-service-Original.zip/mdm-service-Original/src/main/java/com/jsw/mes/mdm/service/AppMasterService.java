package com.jsw.mes.mdm.service;

public interface AppMasterService {
}
