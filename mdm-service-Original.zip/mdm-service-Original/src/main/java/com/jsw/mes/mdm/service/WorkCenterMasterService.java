package com.jsw.mes.mdm.service;

import com.jsw.mes.mdm.entity.WorkCenterMaster;
import com.jsw.mes.mdm.exception.WorkCenterException;
import com.jsw.mes.mdm.model.request.WorkCenterRequest;
import com.jsw.mes.mdm.model.response.WorkCenterResponse;

import java.util.List;

public interface WorkCenterMasterService {
   public WorkCenterResponse addWorkCenter(WorkCenterRequest workCenterRequest) throws WorkCenterException;

    public WorkCenterResponse getWorkCenter(int workCenterId) throws WorkCenterException;

    public WorkCenterResponse updateWorkCenter(WorkCenterRequest workCenterRequest) throws WorkCenterException;

   public WorkCenterResponse deleteWorkCenter(int workCenterId) throws WorkCenterException;

    public List<WorkCenterResponse> getAllWorkCenters() throws WorkCenterException;
}
