package com.jsw.mes.mdm.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperConfiguration {

  /*  @Bean
    public PlantMapper plantMapper(){
        return new PlantMapperImpl();
    }*/

}
